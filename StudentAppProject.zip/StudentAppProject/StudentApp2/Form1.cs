﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentApp2
{
    public partial class Form1 : Form
    {

        HttpClient client = new HttpClient
        {
            BaseAddress = new Uri("https://localhost:5001/api/students")
        };
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private async void btnGet_Click(object sender, EventArgs e)
        {
            var response = await client.GetAsync("");
            var json = await response.Content.ReadAsStringAsync();
            var students = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Student>>(json);
            dataGridView1.DataSource = students;
        }

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            var student = new Student
            {
                FullName = txtName.Text,
                NationalCode = txtCode.Text,
                BirthDate = DateTime.Parse(txtDate.Text)
            };

            var content = new StringContent(JsonConvert.SerializeObject(student), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("", content);

            if (response.IsSuccessStatusCode)
                MessageBox.Show("دانشجو با موفقیت اضافه شد.");

            btnGet_Click(null, null);
        }

        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            var student = new Student
            {
                StudentId = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Id"].Value),
                FullName = txtName.Text,
                NationalCode = txtCode.Text,
                BirthDate = DateTime.Parse(txtDate.Text)
            };

            var content = new StringContent(JsonConvert.SerializeObject(student), Encoding.UTF8, "application/json");
            var response = await client.PutAsync($"/{student.Id}", content);

            if (response.IsSuccessStatusCode)
                MessageBox.Show("ویرایش انجام شد.");

            btnGet_Click(null, null);
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["Id"].Value);
            var response = await client.DeleteAsync($"/{id}");

            if (response.IsSuccessStatusCode)
                MessageBox.Show("دانشجو حذف شد.");

            btnGet_Click(null, null);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            txtName.Text = dataGridView1.CurrentRow.Cells["FullName"].Value.ToString();
            txtCode.Text = dataGridView1.CurrentRow.Cells["NationalCode"].Value.ToString();
            txtDate.Text = Convert.ToDateTime(dataGridView1.CurrentRow.Cells["BirthDate"].Value).ToString("yyyy-MM-dd");
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

     
    }
}

 
 
