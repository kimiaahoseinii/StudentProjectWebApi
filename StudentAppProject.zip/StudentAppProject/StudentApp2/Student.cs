﻿using System;

namespace StudentApp2
{
    internal class Student
    {
        public string FullName { get; internal set; }
        public string NationalCode { get; internal set; }
        public DateTime BirthDate { get; internal set; }
        public int Id { get; internal set; }
        public int StudentId { get; internal set; }
    }
}